#pragma once

#include "detours.h"
#include "getFunc.h"
#include "imgui.h"
#include "imgui_impl_dx9.h"
#include "imgui_impl_win32.h"
#include <d3d9.h>
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
//����ָ�붨��
typedef HRESULT(__stdcall* EndScene)(IDirect3DDevice9*);
typedef HRESULT(__stdcall* RESET)(D3DPRESENT_PARAMETERS*);
typedef void (*GuiRender)(void);

 //�û��������Ⱦ����ָ��
//HOOK��������
HRESULT __stdcall hookEndScene(IDirect3DDevice9* divice);
HRESULT __stdcall hookReset(D3DPRESENT_PARAMETERS* data);


LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

bool SetGui(GuiRender render_ , DWORD button);

void hookEndSceneInit(GuiRender func);

void initHook();


