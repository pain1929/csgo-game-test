
#include <d3d9.h>
void* GetFunc(int index);

    
   